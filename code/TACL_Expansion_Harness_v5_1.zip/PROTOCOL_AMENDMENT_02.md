# Protocol amendment 02: Mistral contextual digit prefix

Amendment date: 2026-09-12 UTC  
Applies to: Mistral engineering qualification and any later qualified Mistral factorial  
Timing: after tokenizer-only static inspection, before any canonical or noncanonical Mistral task outcome

## Observed tokenizer contract

For `mistralai/Mistral-7B-Instruct-v0.3`, each standalone digit is encoded as a
shared whitespace piece followed by a digit-specific piece:

| Answer | Contextual completion before EOS |
|---|---|
| 1 | `[29473, 29508]` |
| 2 | `[29473, 29518]` |
| 3 | `[29473, 29538]` |
| 4 | `[29473, 29549]` |

The first completion token is therefore identical across all choices and
contains no answer information. The original static gate incorrectly tested
standalone string length and rejected this otherwise valid interface.

## Amended readout contract

Append the shared, outcome-invariant answer-prefix token `29473` to every
factorial input. Score the following unique digit tokens `29508`, `29518`,
`29538`, and `29549` with the same gold-versus-best-distractor next-token logit
margin used for the other models.

Before any task scoring, the notebook must reconstruct an assistant completion
for all four digits and verify that it begins with the configured shared prefix
and configured digit token. It must also confirm the four digit tokens are
distinct. The shared prefix becomes part of the suffix/readout geometry in all
conditions, so same-ID and matched-geometry invariants remain exact.

## Scientific status

This amendment responds only to tokenizer structure. No Mistral canonical,
`CE`, `FC`, or `FE` task score had been computed when it was frozen. It does
not change semantic instances, fragmentation calibration, causal conditions,
primary metric, sample size, thresholds, or stopping rules. The superseded v1
configuration remains archived.

