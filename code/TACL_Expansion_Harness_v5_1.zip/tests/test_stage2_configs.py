from pathlib import Path

from tacl_factorization.config import assert_frozen, load_config


ROOT = Path(__file__).resolve().parents[1]


def test_stage2_configs_share_the_locked_design():
    qwen = load_config(ROOT / "configs/qwen_harmonized_robustness_v1.json")
    gemma = load_config(ROOT / "configs/gemma_harmonized_robustness_v1.json")
    for config in (qwen, gemma):
        assert_frozen(config)
        assert config["protocol_version"] == "tacl_harmonized_robustness_v1"
        assert config["semantic_seeds"] == list(range(9000, 9016))
        assert config["engineering_seed"] not in config["semantic_seeds"]
        assert config["conditions"] == ["CC", "CE", "FC", "FE"]
        assert config["filler_languages"] == ["en", "tr"]
        assert config["target_lengths"] == [4096, 8192]
        assert config["expected_rows"] == 256
        assert config["weights"] == "NF4"
        assert config["compute_dtype"] == "bfloat16"
        assert config["attention_implementation"] == "sdpa"
        assert config["stopping_rule"] == "run_all_16_seeds_no_optional_stopping"
        assert config["outcome_rule"] == "report_regardless_of_direction_or_significance"

    assert qwen["inference_path"].startswith("one_shot_no_cache")
    assert gemma["inference_path"].startswith("one_shot_no_cache")
    assert qwen["condition_order_namespace"] == gemma["condition_order_namespace"]
    assert qwen["bootstrap"] == gemma["bootstrap"]
