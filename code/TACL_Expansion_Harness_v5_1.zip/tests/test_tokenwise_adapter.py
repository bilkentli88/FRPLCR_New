import numpy as np

from tacl_factorization.adapters import HFChatAdapter
from tacl_factorization.generator import AssocInstance, CharSpan


class _Tokenizer:
    _pieces = {10: "E\n", 11: "AB", 12: "Q", 13: "<0x0A>", 20: "A", 21: "B"}
    all_special_ids = []

    def __call__(self, text, add_special_tokens=False, return_offsets_mapping=False):
        assert text == "E\nAB\nQ"
        result = {"input_ids": [10, 11, 13, 12]}
        if return_offsets_mapping:
            result["offset_mapping"] = [(0, 2), (2, 4), (4, 5), (5, 6)]
        return result

    def convert_ids_to_tokens(self, token_id):
        return self._pieces[token_id]

    def decode(self, ids, **kwargs):
        pieces = [self._pieces[token_id] for token_id in ids]
        return "".join("\n" if piece == "<0x0A>" else piece for piece in pieces)


class _CanonicalDial:
    _ids = {"E\n": 10, "AB": 11, "Q": 12, "<0x0A>": 13, "A": 20, "B": 21}

    def pre_tokenize(self, text):
        # SentencePiece-like failure mode: the complete message is one chunk.
        return [(text, (0, len(text)))]

    def encode_chunk_pieces(self, chunk):
        assert chunk == "E\nAB\nQ"
        return ["E\n", "AB", "<0x0A>", "Q"]

    def pieces_to_ids(self, pieces):
        return [self._ids[piece] for piece in pieces]


class _FragmentedDial:
    def encode_chunk_pieces(self, piece):
        # The byte-fallback token must never be passed here: encoding its
        # spelling would decode as literal text rather than a newline.
        assert piece == "AB"
        return ["A", "B"]


def _instance():
    return AssocInstance(
        filler_language="en",
        semantic_seed=1,
        trial_index=0,
        target_chat_tokens=6,
        user_content="E\nAB\nQ",
        spans=(
            CharSpan(0, 2, "evidence"),
            CharSpan(2, 5, "filler"),
            CharSpan(5, 6, "query"),
        ),
        target_key="K1",
        gold_digit="1",
        target_record_position=0,
        evidence_lines=("E",),
        filler_lines=("AB",),
        query_lines=("Q",),
    )


def test_adapter_falls_back_to_token_offsets_for_one_whole_message_chunk():
    adapter = object.__new__(HFChatAdapter)
    adapter.tokenizer = _Tokenizer()
    adapter.base_dial = _CanonicalDial()
    adapter.fragmented_dials = {"en": _FragmentedDial()}

    encoding = HFChatAdapter.encode_instance(adapter, _instance())

    assert adapter.last_encoding_strategy == "canonical_token_offsets_v1"
    assert encoding.canonical_ids == (10, 11, 13, 12)
    assert encoding.fragmented_ids == (10, 20, 21, 13, 12)
    assert encoding.canonical_labels == ("evidence", "filler", "filler", "query")
    assert encoding.fragmented_labels == (
        "evidence", "filler", "filler", "filler", "query"
    )
    np.testing.assert_allclose(
        encoding.fragmented_source_positions,
        (0.0, 1.0, 1.5, 2.0, 3.0),
        rtol=0,
        atol=1e-7,
    )


class _CanonicalDialWithRegionChunks(_CanonicalDial):
    def pre_tokenize(self, text):
        return [("E\n", (0, 2)), ("AB\n", (2, 5)), ("Q", (5, 6))]

    def encode_chunk_pieces(self, chunk):
        raise AssertionError("forced token-offset encoding must not use chunk encoding")


def test_configured_token_offset_strategy_overrides_automatic_chunk_dispatch():
    adapter = object.__new__(HFChatAdapter)
    adapter.tokenizer = _Tokenizer()
    adapter.base_dial = _CanonicalDialWithRegionChunks()
    adapter.fragmented_dials = {"en": _FragmentedDial()}
    adapter.encoding_strategy = "canonical_token_offsets_v1"

    encoding = HFChatAdapter.encode_instance(adapter, _instance())

    assert adapter.last_encoding_strategy == "canonical_token_offsets_v1"
    assert encoding.fragmented_ids == (10, 20, 21, 13, 12)
