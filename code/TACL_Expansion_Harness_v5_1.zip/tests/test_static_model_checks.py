from types import SimpleNamespace

from tacl_factorization.qualification import static_model_checks


class _Tokenizer:
    def __call__(self, text, add_special_tokens=False):
        return {"input_ids": [int(text)]}


class _Backbone:
    def forward(self, input_ids=None):
        return None


class _Wrapper:
    def __init__(self):
        self.model = _Backbone()
        self.config = SimpleNamespace(
            model_type="gemma3",
            text_config=SimpleNamespace(max_position_embeddings=32768),
        )

    def forward(self, input_ids=None, position_ids=None):
        return None


def test_static_gate_uses_nested_text_config_and_wrapper_signature():
    observed = static_model_checks(_Wrapper(), _Tokenizer(), required_context=8192)
    assert observed["max_context"] == 32768
    assert observed["position_ids_exposed"] is True
    assert observed["digit_gate"] is True
    assert observed["passed"] is True
