import json
from pathlib import Path

from tacl_factorization.statistics import (
    canonical_metrics,
    compare_reported,
    load_jsonl,
    summarize_factorial,
)


def test_committed_v061_rows_reproduce_reported_statistics_exactly():
    workspace = Path(__file__).resolve().parents[2]
    repo = workspace / "causal_factorization_repo"
    frame = load_jsonl(repo / "data/qwen/v061_factorial_4k8k.jsonl")
    expected = json.loads((repo / "config/reported_results.json").read_text(encoding="utf-8"))[
        "qwen_v061"
    ]
    observed = summarize_factorial(frame)
    assert compare_reported(observed, expected) == []
    assert canonical_metrics(frame) == {
        "canonical_accuracy": expected["canonical_accuracy"],
        "canonical_max_pred_share": expected["canonical_max_pred_share"],
    }

