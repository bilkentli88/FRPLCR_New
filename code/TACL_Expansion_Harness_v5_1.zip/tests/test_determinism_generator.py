from tacl_factorization.determinism import stable_int
from tacl_factorization.generator import (
    gold_for_trial,
    make_key,
    make_records,
    position_rank_for_trial,
    target_position_for_trial,
)


def test_v061_first_instance_contract():
    assert make_key(2000, 0, 32) == "K19969"
    records, target_key, gold, position = make_records(2000, 0, 32)
    assert target_key == "K19969"
    assert gold == "1"
    assert position == 0
    assert records[0] == ("K19969", "1")


def test_balancing_contract():
    assert [gold_for_trial(i) for i in range(8)] == list("12341234")
    assert [position_rank_for_trial(i) for i in range(4)] == [0, 2, 5, 7]
    assert [target_position_for_trial(i) for i in range(4)] == [0, 9, 22, 31]
    assert stable_int("key_v061", 2000, 0, 32) % 90000 + 10000 == 19969

