# Implementation Note 04: force the frozen Gemma encoder

Date: 2026-09-13 UTC

## Trigger

The first Stage-2 Gemma engineering preflight stopped while constructing its
excluded-seed 4K probe. The adapter's automatic dispatch observed separate
evidence, filler, and query pre-tokenization chunks and selected the Qwen v061
chunkwise encoder. For Gemma, concatenating independently encoded chunks does
not reproduce whole-message tokenization, so the pre-existing canonical-ID
equality guard raised `chunkwise canonical encoding mismatch`.

The failure occurred before any call to a scorer, before an engineering audit
was written, and before any confirmatory seed (9000--9015) was constructed or
scored.

## Correction

Harness 0.5.1 adds an explicit `encoding_strategy` field to `HFChatAdapter`.
Both Stage-2 notebooks now pass their frozen `region_labeling` value directly:

- Qwen: `pretoken_chunk_v061`;
- Gemma: `canonical_token_offsets_v1`.

Automatic dispatch remains available only for earlier notebooks that do not
specify a strategy. The Gemma configuration now records
`encoding_selection=force_configured_strategy_v1` and requires harness 0.5.1.

This is an outcome-independent implementation correction: it enforces the
already frozen Gemma v071 token-offset contract and introduces no change to
the seeds, conditions, fragmentation levels, metric, stopping rule, or
analysis.
