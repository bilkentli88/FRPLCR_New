# Validation record

Validation date: 2026-09-13 UTC

## Passed locally

- 15/15 CPU tests passed.
- Source and notebook-builder modules compile without syntax errors.
- Both generated notebooks pass `nbformat` schema validation and every code
  cell parses as Python.
- The new statistics implementation reconstructs all six reported Qwen v061
  means and 95% confidence intervals exactly from the 512 committed raw rows.
- Reconstructed canonical accuracy is 1.0 and maximum predicted-digit share is
  0.25, exactly matching the frozen report.
- Factorial unit tests enforce the same-ID and matched-geometry invariants.
- Resume tests cover duplicate suppression, a torn final JSONL row, and a
  valid final row lacking a newline.

## Frozen configuration hashes

| Configuration | SHA-256 prefix |
|---|---:|
| Qwen v061 reproduction | `f770b0bda4e110d3` |
| Phi engineering qualification v1 (superseded) | `9d8e367e51408f89` |
| Phi engineering qualification v1.1 | `ac26f800309cffee` |
| Phi confirmatory factorial v1 | `af989f16c0b2def5` |
| Mistral engineering qualification v1 (superseded) | `64b1c923289b0d5a` |
| Mistral engineering qualification v1.1 | `c7bb047bdec86614` |
| Mistral confirmatory factorial v1 | `ca7758a9af6fdbf3` |
| Added-model confirmatory factorial | `4ac064e9a6bd238e` |
| Qwen harmonized robustness v1 | `feb116643acbc8b0` |
| Gemma harmonized robustness v1 | `97c623257a61e84e` |

## Requires Colab GPU execution

The Phi engineering notebook cannot be scientifically validated on this CPU
workspace. Its model download, NF4/BF16 inference, 4K/8K memory behavior,
fragmentation calibration, deterministic-repeat test, and 32-instance
canonical-accuracy gate must be run in Colab. This is intentionally the next
stage; no Phi factorial outcome should be inspected before that audit passes.

## Protocol amendment 01

After Phi obtained 30/32 on the canonical-only gate, the original perfect-score
criterion was found to be inconsistent with the manuscript's already accepted
Gemma canonical substrate (as low as 29/32). Before any Phi noncanonical
factorial outcome was accessed, v1.1 replaced the 32/32 rule with a
historically anchored 29/32 overall threshold plus per-cell, response-balance,
and exact-repeat gates. The original v1 configuration remains archived.

## Verified Phi qualification audit

The supplied `phi_engineering_audit.json` has SHA-256
`4ed49da543fcd9be0884660e851bedf8d8e85c3c46acf25d680cafcc8b1a0357`.
All gates pass, no Phi noncanonical factorial outcome had been accessed, and
the frozen fragmentation settings are `en=2` and `tr=2`. The confirmatory
configuration binds to this exact audit hash.

## Protocol amendment 02

Tokenizer inspection showed that Mistral contextualizes every digit with the
same answer-prefix token `29473`, followed by a unique digit token. Before any
Mistral task outcome, v1.1 froze a common-prefix readout: append `29473` to all
conditions, then score digit IDs `29508`, `29518`, `29538`, and `29549`.
CPU tests verify configured contextual candidates and inclusion of the common
prefix in the audited suffix geometry.

## Implementation correction 02

Mistral's backend exposed the complete user message as one pre-tokenization
chunk, preventing evidence/filler/query region labels. Before any Mistral task
score, the adapter gained the frozen Gemma-style token-offset fallback: only
canonical tokens fully inside the filler span are fragmented; boundary tokens
remain canonical. A regression test covers this exact one-chunk failure mode.

## Implementation correction 03

The Mistral geometry-only stage showed that fragmenting the spelling of a
byte-fallback piece such as `<0x0A>` changes decoded text. Before any Mistral
task score, byte-fallback and special tokens were exempted from fragmentation.
The earlier Mistral inflation ledger is excluded, and a newly named ledger is
computed through the same token-offset adapter used by geometry and scoring.

## Verified Mistral qualification audit

The supplied `mistral_engineering_audit.json` has SHA-256
`712204bf1fdfb55c800c4cd667d36ce13041ec2df6a1ade6eb5be8f2f450fdfb`.
All gates pass, canonical accuracy is 32/32, the maximum predicted-digit share
is 0.25, the repeat candidate-logit difference is exactly zero, and no
factorial outcome had been accessed. The frozen fragmentation settings are
`en=5` and `tr=1`; the Mistral confirmatory configuration binds to this exact
audit hash.

## Frozen Stage-2 matched-path robustness

Qwen and Gemma now have separate Colab notebooks using NF4/BF16, SDPA,
one-shot/no-cache execution, fresh seeds 9000--9015, and sequential causal
visibility. Qwen uses the validated boolean full-attention mask; Gemma retains
the finite additive full/sliding masks required by its architecture. Both
notebooks resolve and record the repository commit before task scoring, use
excluded engineering seed 8999, reuse rather than overwrite a passed audit,
and lock effect analysis until exactly 256 paired rows are present.

The GPU/model-dependent preflights and confirmatory rows cannot be executed in
this CPU workspace. The notebook schemas, every Python code cell, frozen
cross-config invariants, packaging, and clean-install behavior are validated
locally; the actual NF4/BF16 scorer gates remain for Colab execution.

## Implementation correction 04

The first Gemma Stage-2 preflight stopped before scoring because automatic
adapter dispatch selected chunkwise encoding even though Gemma's frozen
contract specifies token-offset encoding. Harness 0.5.1 now takes the encoding
strategy explicitly from each frozen configuration. A regression test proves
that the Gemma token-offset strategy overrides automatic chunk dispatch. No
engineering audit or confirmatory row existed when this correction was made.
