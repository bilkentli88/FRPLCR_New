# Implementation Note 03: preserve byte-fallback tokens and recalibrate

**Frozen:** 2026-09-13, before any Mistral canonical or factorial task score
was produced or inspected.

## Trigger

After token-offset region labeling was introduced, the geometry-only cell
stopped at the exact-decode invariant. Mistral represents line breaks with
byte-fallback pieces such as `<0x0A>`. Passing that piece spelling through the
fragmentation encoder yields ordinary tokens for the literal spelling rather
than the original byte semantics.

The preceding inflation scan had also called the older chunkwise encoder
directly. Because Mistral exposes the user message as one pre-tokenization
chunk, those rows did not measure the same filler-only intervention and cannot
be used to select a fragmentation level.

## Correction

1. Byte-fallback pieces matching `<0xHH>` and tokenizer special tokens are
   always retained canonically.
2. The Mistral calibration scan now calls the same adapter encoding path as
   geometry and scoring.
3. Calibration is written to a new ledger,
   `mistral_engineering_fragmentation_scan_tokenwise_v1.jsonl`; the earlier
   ledger remains untouched but is excluded from selection.
4. The exact full-sequence decode invariant remains mandatory.

## Scientific status

This is an outcome-independent tokenizer correction. It changes no task text,
seed, model weight, candidate answer, target inflation range, qualification
threshold, or estimand. No Mistral task score or factorial contrast had been
accessed when it was made. Fragmentation keep levels are recalibrated because
the valid intervention has a different token-count inflation from the invalid
whole-chunk scan.
